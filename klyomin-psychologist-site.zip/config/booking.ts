export const BOOKING_TIMEZONE = "Asia/Irkutsk";
export const BOOKING_TIMEZONE_LABEL = "Время указано по Иркутску (UTC+8).";

/**
 * Google Calendar Appointment Schedule URLs.
 * Paste the real booking-page URLs here after Evgeny restores Google Calendar.
 *
 * Google supports both a public booking-page link and an inline booking-page embed.
 * This project intentionally does NOT recreate availability locally.
 */
export const bookingConfig = {
  individualOffline: "",
  individualOnline: "",
  family: "",
  diagnostics: "",
} as const;

export type BookingServiceId = keyof typeof bookingConfig;

export const hasBookingUrl = (id: BookingServiceId) =>
  Boolean(bookingConfig[id]);