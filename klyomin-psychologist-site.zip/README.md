# Сайт клинического психолога Евгения Клёмина

Conversion-focused Next.js сайт: главная цель — запись на консультацию.

## Что уже реализовано

- Next.js + TypeScript
- responsive mobile-first UI
- sticky CTA на мобильном
- единый главный CTA «Записаться на консультацию»
- услуги и цены
- booking architecture на Google Calendar Appointment Schedules
- 4 отдельных booking URL
- fallback, если URL ещё не добавлены
- Иркутск (UTC+8) в интерфейсе
- не создаётся локальная система доступности
- FAQ
- структура отзывов без фейковых отзывов
- placeholders для неподтверждённых профессиональных данных
- страница Privacy с юридическим placeholder
- /articles и /articles/[slug]
- SEO metadata
- canonical
- robots.txt
- sitemap.xml
- Open Graph metadata
- favicon
- Яндекс Метрика
- JS-event tracking
- UTM preservation
- session/local storage для первоначального UTM
- accessibility-oriented semantic HTML
- lazy iframe/map
- AVIF/WebP image config
- минимальный набор зависимостей

## Архитектура

```text
/app
  /articles
  /privacy
  globals.css
  layout.tsx
  page.tsx
  robots.ts
  sitemap.ts

/components
  AnalyticsBridge.tsx
  Booking.tsx
  SiteHeader.tsx

/config
  booking.ts
  site.ts

/lib
  analytics.ts

/public
  favicon.svg
  manifest.webmanifest
```

## 1. Локальный запуск

Требуется Node.js 20+.

```bash
npm install
npm run dev
```

Откройте `http://localhost:3000`.

Production build:

```bash
npm run build
npm start
```

## 2. Google Calendar

Google Calendar Appointment Schedules является source of truth.

В Google Calendar:

1. Создайте Appointment schedule.
2. Настройте длительность и доступность.
3. Настройте место встречи.
4. Скопируйте booking-page URL.
5. При необходимости используйте Google-generated Website Embed.
6. Вставьте URL в `config/booking.ts`.

```ts
export const bookingConfig = {
  individualOffline: "PASTE_URL_HERE",
  individualOnline: "PASTE_URL_HERE",
  family: "PASTE_URL_HERE",
  diagnostics: "PASTE_URL_HERE",
};
```

Сайт намеренно не вычисляет свободные слоты самостоятельно.

Google подтверждает, что Appointment Schedules создают booking page, учитывают занятость календаря и позволяют поделиться ссылкой или встроить booking page на сайт.

Если inline embed для конкретной конфигурации не используется, код автоматически показывает безопасный fallback. В production перед публикацией хотя бы одна реальная booking URL должна быть добавлена.

## 3. Ограничение времени

На сайте используется:

```ts
BOOKING_TIMEZONE = "Asia/Irkutsk";
```

Интерфейс явно показывает:

> Время указано по Иркутску (UTC+8).

Сам сайт не генерирует слоты. Ограничение «не показывать время позже 00:00» должно быть настроено непосредственно в соответствующем Google Calendar Appointment Schedule. Это важно: сайт не должен притворяться источником доступности.

## 4. Яндекс Метрика

Создайте счётчик в Яндекс Метрике.

После получения ID:

`.env.local`

```env
NEXT_PUBLIC_YANDEX_METRICA_ID=12345678
NEXT_PUBLIC_SITE_URL=https://ваш-домен.ru
```

Перезапустите dev server / redeploy.

События:

- `page_view`
- `click_book`
- `booking_section_open`
- `booking_service_selected`
- `booking_calendar_open`
- `booking_completed`
- `telegram_click`
- `phone_click`
- `b17_click`
- `vk_click`
- `instagram_click`
- `map_click`
- `service_view`
- `faq_open`

Для JS event goals создайте соответствующие цели в интерфейсе Метрики.

Важно: факт `booking_completed` нельзя достоверно зарегистрировать внутри сайта, если человек завершает запись внутри внешнего Google booking flow и нет разрешённого callback/интеграционного механизма. Поэтому проект не фальсифицирует эту конверсию.

Для реальной воронки используйте:

traffic source → landing → click_book → booking_section_open → booking_calendar_open → фактическая запись.

## 5. UTM

Поддерживаются:

- `utm_source`
- `utm_medium`
- `utm_campaign`
- `utm_content`
- `utm_term`

Пример:

```text
https://ваш-домен.ru/?utm_source=b17&utm_medium=profile&utm_campaign=jenya
```

Первоначальные UTM сохраняются в sessionStorage и localStorage.

Рекомендуемые source:

- b17
- yandex
- google
- 2gis
- telegram
- vk
- instagram
- direct
- organic

## 6. Отзывы

Замените:

- `[ОТЗЫВ 1]`
- `[ОТЗЫВ 2]`
- `[ОТЗЫВ 3]`

на реальные тексты, которые разрешено публиковать.

Не добавляйте персональные данные клиентов.

После добавления реальных отзывов можно расширить блок раскрывающимся текстом.

## 7. Фото

В hero сейчас используется явный placeholder.

Замените его на реальное оптимизированное изображение.

Рекомендуемый вариант:

```text
/public/evgeny-klyomin.webp
```

После добавления файла замените placeholder в `app/page.tsx` на `next/image`.

Не используйте стоковое фото другого психолога.

## 8. B17 / VK / Telegram / Instagram / телефон

Все ссылки вынесены в:

```text
/config/site.ts
```

Замените:

```ts
telegramUrl: "",
vkUrl: "",
instagramUrl: "",
phone: "",
```

B17 уже указан как:

```ts
b17Url: "https://www.b17.ru/klyomin/"
```

## 9. Что нужно дополнить перед production

### Критично

- [ ] Реальный домен
- [ ] Реальные Google Calendar booking URLs
- [ ] Фото Евгения
- [ ] Подтверждённое образование
- [ ] Подтверждённый опыт
- [ ] Квалификации
- [ ] Дополнительное обучение
- [ ] Реальные отзывы
- [ ] Telegram URL
- [ ] Телефон, если нужен
- [ ] VK URL
- [ ] Instagram URL, если нужен
- [ ] Правила отмены/переноса
- [ ] Реальная длительность психодиагностики
- [ ] Юридически проверенная Privacy Policy
- [ ] Yandex Metrica ID

### Желательно

- [ ] Реальный URL сайта в metadataBase
- [ ] Реальный OG image
- [ ] Favicon/иконка бренда при необходимости
- [ ] Проверка карты и адреса
- [ ] Проверка всех внешних ссылок
- [ ] Проверка юридической допустимости онлайн-консультаций для конкретной географии

## 10. GitHub

Создайте аккаунт на GitHub.

В корне проекта:

```bash
git init
git add .
git commit -m "Initial production website"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/klyomin-psychologist-site.git
git push -u origin main
```

## 11. Vercel

1. Создайте аккаунт Vercel.
2. Add New → Project.
3. Import Git Repository.
4. Выберите `klyomin-psychologist-site`.
5. Framework Preset: Next.js.
6. Добавьте Environment Variables:

```text
NEXT_PUBLIC_YANDEX_METRICA_ID
NEXT_PUBLIC_SITE_URL
```

7. Deploy.

После каждого push в `main` Vercel будет собирать новую версию.

## 12. Домен

В Vercel:

Project → Settings → Domains → Add Domain.

Vercel покажет DNS-записи.

На стороне регистратора домена добавьте именно те записи, которые выдаст Vercel. Не копируйте DNS-инструкции из случайных гайдов — значения могут отличаться.

После подключения:

1. обновите `NEXT_PUBLIC_SITE_URL`
2. обновите `metadataBase`
3. обновите `robots.ts`
4. обновите `sitemap.ts`
5. redeploy.

## 13. SEO

Перед запуском замените `https://example.com` в:

- `app/layout.tsx`
- `app/robots.ts`
- `app/sitemap.ts`

Title и description уже ориентированы на локальный коммерческий intent.

Не добавляйте keyword stuffing.

После появления реальных подтверждённых данных можно добавить корректные Schema.org данные. Не добавляйте фиктивные рейтинги, отзывы или медицинские квалификации.

## 14. CRO review

### Первые 5 секунд

Пользователь видит:

- кто специалист;
- Иркутск / онлайн;
- основные типы запросов;
- CTA;
- цену «от 3000 ₽».

### Понятность специалиста

Да: «Клинический психолог Евгений Клёмин».

### Понятность проблем

Да: запросы сформулированы человеческим языком до профессиональной терминологии.

### Цена

Да, в hero и полном виде в услугах.

### Доверие

Строится через прозрачные условия, процесс, реальные отзывы и профессиональные данные без выдумок.

### CTA

Главный CTA повторяется по всей странице и есть sticky CTA на мобильном.

### Запись без переписки

Да, после добавления реальных Google Calendar URLs.

### Что происходит после клика

Пользователь попадает к выбору формата и реальному Google Calendar booking flow.

### Причина продолжить скроллить

Последовательность построена от узнавания проблемы → услуг → процесса → специалиста → отзывов → FAQ → записи.

### Главные потенциальные барьеры

- нет реальных отзывов;
- нет подтверждённой биографии;
- нет booking URLs;
- нет фото;
- нет юридически финализированной privacy policy.

Именно их стоит закрыть перед запуском.

## 15. A/B testing

Тексты hero и CTA находятся непосредственно в компоненте страницы, поэтому их легко заменить.

Для следующего этапа можно вынести варианты в:

```text
/config/experiments.ts
```

и передавать вариант через cookie/URL/analytics.

Сейчас сложная A/B инфраструктура намеренно не добавляется: сначала нужен baseline с реальными данными.

## 16. Что не реализовано намеренно

- собственная база слотов;
- собственный booking backend;
- регистрация пользователей;
- длинная анкета;
- сбор диагноза;
- фейковые отзывы;
- выдуманная биография;
- фиктивная доступность;
- тяжёлые UI-библиотеки;
- ненужные анимации.

Это сделано специально, потому что главная бизнес-цель — запись, а Google Calendar должен оставаться единственным источником истины.

## 17. Финальный launch checklist

- [ ] `npm run build` проходит
- [ ] реальный домен прописан
- [ ] Google Calendar URLs работают
- [ ] время в Google Calendar настроено по Asia/Irkutsk
- [ ] после 00:00 не предлагаются слоты
- [ ] все CTA ведут в booking
- [ ] Telegram работает
- [ ] карта работает
- [ ] B17 работает
- [ ] реальные фото загружены
- [ ] реальные отзывы загружены
- [ ] профессиональные данные подтверждены
- [ ] Privacy Policy проверена юристом
- [ ] Яндекс Метрика получает page views
- [ ] JS event goals проверены
- [ ] UTM сохраняются
- [ ] mobile checked
- [ ] keyboard navigation checked
- [ ] Lighthouse / Core Web Vitals checked
- [ ] broken links checked
