import fs from "node:fs";
import path from "node:path";

const root = process.cwd();
const ignored = new Set(["node_modules", ".next", ".git"]);
const needles = ["lorem ipsum", "TODO", "[ОТЗЫВ", "[ОБРАЗОВАНИЕ", "[ФОТО"];

function walk(dir) {
  const out = [];
  for (const name of fs.readdirSync(dir)) {
    if (ignored.has(name)) continue;
    const full = path.join(dir, name);
    const stat = fs.statSync(full);
    if (stat.isDirectory()) out.push(...walk(full));
    else out.push(full);
  }
  return out;
}

const matches = [];
for (const file of walk(root)) {
  if (!/\.(ts|tsx|md|css|json|mjs|txt)$/.test(file)) continue;
  const text = fs.readFileSync(file, "utf8").toLowerCase();
  for (const needle of needles) if (text.includes(needle.toLowerCase())) matches.push({ file, needle });
}

console.log("Intentional placeholders found:");
for (const item of matches) console.log(`- ${item.file}: ${item.needle}`);
console.log(`Total: ${matches.length}`);
