import Link from "next/link";

export default async function ArticlePage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;

  return (
    <main className="section">
      <div className="container" style={{ maxWidth: 850 }}>
        <Link href="/articles">← Все статьи</Link>
        <div style={{ marginTop: 44 }}>
          <span className="placeholder-tag">ARTICLE PLACEHOLDER</span>
          <h1 style={{ fontSize: "clamp(42px, 6vw, 64px)", marginTop: 16 }}>[ЗАГОЛОВОК СТАТЬИ]</h1>
          <p className="muted" style={{ marginTop: 14 }}>slug: {slug} · [ДАТА]</p>
          <div style={{ marginTop: 38, display: "grid", gap: 20 }}>
            <p className="lead">[АННОТАЦИЯ СТАТЬИ]</p>
            <p>[ТЕКСТ ЭКСПЕРТНОЙ СТАТЬИ]</p>
            <p>[ТЕКСТ ЭКСПЕРТНОЙ СТАТЬИ]</p>
          </div>
          <div style={{ marginTop: 42 }}>
            <a className="button button--primary" href="/#booking" data-track="click_book">Записаться на консультацию</a>
          </div>
        </div>
      </div>
    </main>
  );
}