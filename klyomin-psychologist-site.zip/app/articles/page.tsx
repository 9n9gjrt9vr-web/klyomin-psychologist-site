import Link from "next/link";

const articles = [
  { slug: "placeholder-1", title: "[СТАТЬЯ 1 — ДОБАВИТЬ]", description: "Placeholder для будущей экспертной статьи.", date: "2026-01-01" },
  { slug: "placeholder-2", title: "[СТАТЬЯ 2 — ДОБАВИТЬ]", description: "Placeholder для будущей экспертной статьи.", date: "2026-01-01" },
  { slug: "placeholder-3", title: "[СТАТЬЯ 3 — ДОБАВИТЬ]", description: "Placeholder для будущей экспертной статьи.", date: "2026-01-01" },
];

export default function ArticlesPage() {
  return (
    <main className="section">
      <div className="container">
        <Link href="/">← На главную</Link>
        <div style={{ marginTop: 44 }}>
          <span className="eyebrow">Экспертные материалы</span>
          <h1>Статьи</h1>
          <p className="lead" style={{ marginTop: 20 }}>
            Раздел подготовлен для будущих материалов. Блог не является главным способом конверсии сайта.
          </p>
        </div>
        <div className="card-grid" style={{ marginTop: 46 }}>
          {articles.map((article) => (
            <article className="card" key={article.slug}>
              <span className="placeholder-tag">PLACEHOLDER</span>
              <h3>{article.title}</h3>
              <p>{article.description}</p>
              <Link className="button button--secondary button--small" style={{ marginTop: 22 }} href={`/articles/${article.slug}`}>Открыть</Link>
            </article>
          ))}
        </div>
      </div>
    </main>
  );
}