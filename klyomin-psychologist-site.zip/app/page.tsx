import { siteConfig } from "@/config/site";
import { Booking } from "@/components/Booking";
import { SiteHeader } from "@/components/SiteHeader";
import { AnalyticsBridge } from "@/components/AnalyticsBridge";

const concerns = [
  ["Тревога и депрессивные симптомы", "Когда тревожные или сниженные состояния начинают заметно влиять на повседневную жизнь."],
  ["Проблемы в отношениях", "Повторяющиеся конфликты, сложные привязанности, расставания и непонятные сценарии близости."],
  ["Эмоциональная нестабильность", "Сильные реакции, перепады состояния и трудности с пониманием собственных чувств."],
  ["Последствия травматического опыта", "Когда прошлый опыт продолжает влиять на настоящее, отношения или самоощущение."],
  ["Повторяющиеся сценарии", "Когда вы уже понимаете проблему, но снова оказываетесь примерно в той же точке."],
  ["Длительные психологические трудности", "Запросы, которые не решаются простым советом и требуют внимательной, последовательной работы."],
  ["Личностные особенности", "Когда устойчивые способы воспринимать себя и других создают сложности в жизни и отношениях."],
  ["Кризисные ситуации", "Периоды, когда привычные способы справляться перестают работать и нужно разобраться, что происходит."],
  ["Психодиагностика", "Структурированная работа, когда важно подробнее исследовать психологические особенности и состояние."],
  ["Запросы близких", "Консультации для людей, которые хотят лучше понять ситуацию близкого человека и способы взаимодействия с ним."],
];

const recognitions = [
  "«Я понимаю, что со мной что-то происходит, но не могу понять что именно.»",
  "«Я снова оказываюсь в похожих отношениях, хотя каждый раз обещаю себе, что больше так не будет.»",
  "«Я понимаю, что прошлое давно закончилось, но оно всё ещё влияет на мою жизнь.»",
  "«Я могу объяснить себе всё рационально, но от этого ничего не меняется.»",
  "«Тревога или эмоциональные реакции мешают мне жить так, как я хочу.»",
  "«Я уже многое читал и понимаю про себя, но проблема всё равно повторяется.»",
];

export default function HomePage() {
  return (
    <>
      <AnalyticsBridge />
      <SiteHeader />

      <main>
        <section className="hero">
          <div className="container hero-grid">
            <div className="hero-copy">
              <span className="eyebrow">Клинический психолог · Иркутск / онлайн</span>
              <h1>Если проблема повторяется, важно понять, почему.</h1>
              <p className="lead">
                Помогаю разобраться в том, что происходит с вами сейчас:
                тревоге, отношениях, эмоциональных реакциях, последствиях
                травматического опыта и повторяющихся психологических сценариях.
              </p>
              <div className="hero-actions">
                <a className="button button--primary" href="#booking" data-track="click_book">
                  Записаться на консультацию
                </a>
                <a className="button button--secondary" href="#booking">
                  Посмотреть свободные даты
                </a>
              </div>
              <div className="hero-meta">
                <span>Очный приём: Иркутск, ул. Лермонтова, 281/3</span>
                <span>Консультация — от 3000 ₽</span>
              </div>
            </div>

            <div className="portrait" aria-label="Фотография Евгения Клёмина">
              <div className="photo-placeholder">
                <div>
                  <strong>[ФОТО ЕВГЕНИЯ]</strong>
                  <p style={{ marginTop: 8 }}>Замените этот блок на оптимизированное портретное фото.</p>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section className="section soft" aria-labelledby="recognition">
          <div className="container">
            <div className="section-head">
              <div>
                <span className="eyebrow">Возможно, вы узнаете себя</span>
                <h2 id="recognition">Не обязательно заранее знать, «что с вами».</h2>
              </div>
              <p className="lead">Можно прийти с ощущением, вопросом или проблемой — и вместе разобраться, что за ней стоит.</p>
            </div>
            <div className="quote-grid">
              {recognitions.map((item) => <div className="quote-card" key={item}><p>{item}</p></div>)}
            </div>
          </div>
        </section>

        <section className="section" id="concerns" aria-labelledby="concerns-title">
          <div className="container">
            <div className="section-head">
              <div>
                <span className="eyebrow">С чем обращаются</span>
                <h2 id="concerns-title">От понятной жалобы до сложного случая.</h2>
              </div>
              <p className="lead">Не нужно самостоятельно ставить себе диагноз. На первой встрече можно начать с того, что беспокоит вас.</p>
            </div>
            <div className="card-grid cards-4">
              {concerns.map(([title, text], index) => (
                <article className="card" key={title}>
                  <div className="card-number">{String(index + 1).padStart(2, "0")}</div>
                  <h3>{title}</h3>
                  <p>{text}</p>
                </article>
              ))}
            </div>
          </div>
        </section>

        <section className="section soft">
          <div className="container">
            <div className="about-grid">
              <div>
                <span className="eyebrow">Почему бывает сложно</span>
                <h2>Иногда проблема держится не потому, что вы недостаточно стараетесь.</h2>
              </div>
              <div className="about-copy">
                <p className="lead">Одно и то же поведение может снова появляться в разных отношениях. Понимание причин не всегда автоматически меняет привычный способ реагировать.</p>
                <p>В работе важно не только обсудить отдельный симптом, но и внимательно посмотреть на контекст: отношения, эмоции, повторяющиеся реакции, опыт прошлого и то, как вы воспринимаете себя и других.</p>
                <p>Это не означает, что на первой встрече обязательно нужно разобрать всю жизнь. Работа начинается с актуального запроса и постепенно уточняется.</p>
              </div>
            </div>
          </div>
        </section>

        <section className="section" id="services" aria-labelledby="services-title">
          <div className="container">
            <div className="section-head">
              <div>
                <span className="eyebrow">Услуги и стоимость</span>
                <h2 id="services-title">Понятные условия без сюрпризов.</h2>
              </div>
              <p className="lead">Выберите формат, который подходит вам. Свободное время показывается из Google Calendar Евгения.</p>
            </div>
            <div className="service-grid">
              {[
                ["Индивидуальная очная консультация", "3000 ₽", "60 минут", "Для индивидуального запроса в кабинете в Иркутске.", "individualOffline"],
                ["Индивидуальная онлайн-консультация", "3000 ₽", "60 минут", "Для тех, кому удобнее работать дистанционно.", "individualOnline"],
                ["Семейная консультация", "4500 ₽", "90 минут", "Для совместной работы с отношениями и взаимодействием.", "family"],
                ["Психодиагностика", "5000 ₽", "[ПРОДОЛЖИТЕЛЬНОСТЬ — ДОБАВИТЬ]", "Структурированная диагностическая работа по согласованному запросу.", "diagnostics"],
              ].map(([title, price, duration, text, id]) => (
                <article className="card service-card" key={id} data-track="service_view">
                  <div className="service-top">
                    <h3>{title}</h3>
                    <strong className="price">{price}</strong>
                  </div>
                  <p>{duration}</p>
                  <p>{text}</p>
                  <a className="button button--secondary button--small" href={`#booking?service=${id}`}>Выбрать и записаться</a>
                </article>
              ))}
            </div>
          </div>
        </section>

        <section className="section soft" aria-labelledby="process-title">
          <div className="container">
            <div className="section-head">
              <div>
                <span className="eyebrow">Первая встреча</span>
                <h2 id="process-title">Без экзамена и необходимости всё заранее объяснить.</h2>
              </div>
              <p className="lead">Задача первой встречи — понять ваш запрос и определить, какой формат дальнейшей работы имеет смысл.</p>
            </div>
            <div className="process">
              {[
                ["01", "Знакомство", "Формулируем, с чем вы пришли и что сейчас важно."],
                ["02", "Разбор ситуации", "Смотрим на происходящее подробнее, не сводя всё к одному симптому."],
                ["03", "Направление", "Определяем возможные направления дальнейшей работы."],
                ["04", "Следующие шаги", "Если необходимо, переходим к терапевтической или диагностической работе."],
              ].map(([n, title, text]) => (
                <article className="card" key={n}>
                  <div className="card-number">{n}</div>
                  <h3>{title}</h3>
                  <p>{text}</p>
                </article>
              ))}
            </div>
          </div>
        </section>

        <section className="section" id="about" aria-labelledby="about-title">
          <div className="container">
            <div className="about-grid">
              <div>
                <span className="eyebrow">О специалисте</span>
                <h2 id="about-title">Евгений Клёмин</h2>
                <p className="muted" style={{ marginTop: 12 }}>Клинический психолог · Иркутск / онлайн</p>
              </div>
              <div className="about-copy">
                <p className="lead">Профессиональная информация здесь намеренно не придумана: она будет заполнена на основе подтверждённых данных.</p>
                <p><strong>[ОБРАЗОВАНИЕ]</strong></p>
                <p><strong>[ОПЫТ]</strong></p>
                <p><strong>[КВАЛИФИКАЦИЯ]</strong></p>
                <p><strong>[ДОПОЛНИТЕЛЬНОЕ ОБУЧЕНИЕ]</strong></p>
                <p><a href={siteConfig.b17Url} target="_blank" rel="noreferrer" data-track="b17_click">Профиль Евгения на B17 →</a></p>
              </div>
            </div>
          </div>
        </section>

        <section className="section soft" aria-labelledby="methods-title">
          <div className="container">
            <div className="section-head">
              <div>
                <span className="eyebrow">Подход к работе</span>
                <h2 id="methods-title">Методы — инструмент, а не витрина.</h2>
              </div>
              <p className="lead">Конкретный формат работы определяется запросом и ситуацией человека, а не наоборот.</p>
            </div>
            <div className="method-list">
              {[
                ["Клинический взгляд", "Внимание к симптомам, контексту, устойчивым паттернам и особенностям личности."],
                ["Диалог и исследование", "Вместе уточняем, как устроена проблема и что поддерживает её сейчас."],
                ["Психодиагностика", "При необходимости используются диагностические инструменты для более глубокого понимания запроса."],
                ["Гипноз и дополнительные методы", "[ПОДТВЕРДИТЬ И ДОБАВИТЬ КОРРЕКТНОЕ ОПИСАНИЕ МЕТОДОВ ПО ДАННЫМ ЕВГЕНИЯ]"],
              ].map(([title, text]) => (
                <div className="method-item" key={title}>
                  <strong>{title}</strong>
                  <p className="muted">{text}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section className="section" id="reviews" aria-labelledby="reviews-title">
          <div className="container">
            <div className="section-head">
              <div>
                <span className="eyebrow">Отзывы</span>
                <h2 id="reviews-title">Реальные отзывы — без генерации.</h2>
              </div>
              <p className="lead">Здесь будут размещены только отзывы, которые действительно были предоставлены для публикации.</p>
            </div>
            <div className="review-grid">
              {["[ОТЗЫВ 1]", "[ОТЗЫВ 2]", "[ОТЗЫВ 3]"].map((x) => (
                <article className="review" key={x}>
                  <span className="placeholder-tag">{x}</span>
                  <p>Заменить на реальный текст отзыва без персональных данных клиента.</p>
                </article>
              ))}
            </div>
          </div>
        </section>

        <section className="section soft" id="faq" aria-labelledby="faq-title">
          <div className="container">
            <div className="section-head">
              <div>
                <span className="eyebrow">FAQ</span>
                <h2 id="faq-title">Частые вопросы</h2>
              </div>
            </div>
            <div className="faq">
              {[
                ["Сколько стоит консультация?", "Индивидуальная очная и онлайн-консультация — 3000 ₽ за 60 минут. Семейная консультация — 4500 ₽ за 90 минут. Психодиагностика — 5000 ₽."],
                ["Можно ли обратиться онлайн?", "Да. Онлайн-консультации доступны при технической и юридической возможности для клиента."],
                ["Как проходит первая консультация?", "Вы рассказываете, что привело вас на консультацию. Вместе уточняете запрос и разбираете ситуацию. Дальше определяются возможные направления работы."],
                ["Нужно ли заранее знать свой диагноз?", "Нет. Самостоятельно ставить себе диагноз не нужно."],
                ["Можно ли прийти с проблемами в отношениях?", "Да. Это один из распространённых типов запросов."],
                ["Работаете ли вы с последствиями травматического опыта?", "Да, такие запросы входят в специализацию. Конкретный формат работы определяется индивидуально."],
                ["Можно ли сначала просто разобраться, что со мной происходит?", "Да. Не обязательно приходить с готовым диагнозом или точной формулировкой проблемы."],
                ["Как записаться?", "Выберите подходящую услугу в блоке записи и откройте актуальное расписание. Свободные слоты берутся непосредственно из Google Calendar."],
                ["Что делать, если мне не подходит ни один свободный слот?", "Свяжитесь с Евгением напрямую через Telegram или другой доступный контакт — ближайшее возможное время можно уточнить отдельно."],
                ["Можно ли отменить или перенести запись?", "[ПРАВИЛА ОТМЕНЫ/ПЕРЕНОСА — ДОБАВИТЬ]"],
              ].map(([q, a]) => (
                <details key={q}>
                  <summary>{q}</summary>
                  <p>{a}</p>
                </details>
              ))}
            </div>
          </div>
        </section>

        <Booking />

        <section className="section" id="contacts" aria-labelledby="contacts-title">
          <div className="container">
            <div className="section-head">
              <div>
                <span className="eyebrow">Контакты</span>
                <h2 id="contacts-title">Очный приём и связь</h2>
              </div>
            </div>
            <div className="contact-grid">
              <article className="contact-card">
                <h3>Кабинет</h3>
                <p className="muted" style={{ marginTop: 10 }}>Иркутск, ул. Лермонтова, 281/3</p>
                <a className="button button--secondary button--small" style={{ marginTop: 20 }} href="https://yandex.ru/maps/?text=Иркутск%20ул.%20Лермонтова%20281%2F3" target="_blank" rel="noreferrer" data-track="map_click">Построить маршрут</a>
                <iframe
                  className="map"
                  title="Карта: Иркутск, ул. Лермонтова, 281/3"
                  loading="lazy"
                  src="https://yandex.ru/map-widget/v1/?text=Иркутск%20ул.%20Лермонтова%20281%2F3"
                />
              </article>
              <article className="contact-card">
                <h3>Онлайн</h3>
                <p className="muted" style={{ marginTop: 10 }}>Россия и другие страны, если это технически и юридически возможно для клиента.</p>
                <div className="contact-links">
                  {siteConfig.telegramUrl ? <a className="button button--secondary button--small" href={siteConfig.telegramUrl} target="_blank" rel="noreferrer" data-track="telegram_click">Telegram</a> : <span className="placeholder-tag">[TELEGRAM URL]</span>}
                  {siteConfig.phone ? <a className="button button--secondary button--small" href={`tel:${siteConfig.phone}`} data-track="phone_click">Позвонить</a> : <span className="placeholder-tag">[ТЕЛЕФОН]</span>}
                  {siteConfig.vkUrl ? <a className="button button--secondary button--small" href={siteConfig.vkUrl} target="_blank" rel="noreferrer" data-track="vk_click">VK</a> : null}
                  {siteConfig.instagramUrl ? <a className="button button--secondary button--small" href={siteConfig.instagramUrl} target="_blank" rel="noreferrer" data-track="instagram_click">Instagram</a> : null}
                </div>
              </article>
            </div>
          </div>
        </section>
      </main>

      <footer className="footer">
        <div className="container footer-grid">
          <div>© {new Date().getFullYear()} Евгений Клёмин</div>
          <div><a href="/privacy">Политика конфиденциальности</a> · <a href={siteConfig.b17Url} target="_blank" rel="noreferrer">B17</a></div>
        </div>
      </footer>

      <div className="mobile-cta">
        <a className="button button--primary" href="#booking" data-track="click_book">Записаться</a>
      </div>
    </>
  );
}