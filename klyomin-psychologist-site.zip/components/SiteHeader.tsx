import { siteConfig } from "@/config/site";

export function SiteHeader() {
  return (
    <header className="site-header">
      <div className="container header-inner">
        <a className="brand" href="/" aria-label="Евгений Клёмин — на главную">Евгений Клёмин</a>
        <nav className="nav" aria-label="Основная навигация">
          <a href="#services">Услуги</a>
          <a href="#about">О специалисте</a>
          <a href="#reviews">Отзывы</a>
          <a href="#faq">FAQ</a>
          <a href="#contacts">Контакты</a>
        </nav>
        <a className="button button--primary button--small" href="#booking" data-track="click_book">Записаться</a>
      </div>
    </header>
  );
}