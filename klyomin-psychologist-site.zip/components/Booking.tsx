"use client";

import { useEffect, useMemo, useState } from "react";
import { bookingConfig, hasBookingUrl, type BookingServiceId, BOOKING_TIMEZONE_LABEL } from "@/config/booking";
import { trackEvent } from "@/lib/analytics";

const options: { id: BookingServiceId; title: string; meta: string }[] = [
  { id: "individualOffline", title: "Индивидуальная очная", meta: "3000 ₽ · 60 минут" },
  { id: "individualOnline", title: "Индивидуальная онлайн", meta: "3000 ₽ · 60 минут" },
  { id: "family", title: "Семейная", meta: "4500 ₽ · 90 минут" },
  { id: "diagnostics", title: "Психодиагностика", meta: "5000 ₽ · длительность уточняется" },
];

export function Booking() {
  const [selected, setSelected] = useState<BookingServiceId>("individualOffline");

  const url = useMemo(() => bookingConfig[selected], [selected]);

  useEffect(() => {
    const hash = window.location.hash;
    if (hash.startsWith("#booking?service=")) {
      const value = new URLSearchParams(hash.split("?")[1]).get("service");
      const match = options.find((o) => o.id === value);
      if (match) setSelected(match.id);
    }
  }, []);

  const choose = (id: BookingServiceId) => {
    setSelected(id);
    trackEvent("booking_service_selected", { service: id });
  };

  const openBooking = () => {
    trackEvent("booking_calendar_open", { service: selected });
  };

  return (
    <section className="section soft" id="booking" aria-labelledby="booking-title">
      <div className="container">
        <div className="section-head">
          <div>
            <span className="eyebrow">Запись</span>
            <h2 id="booking-title">Выберите формат и время.</h2>
          </div>
          <p className="lead">
            {BOOKING_TIMEZONE_LABEL} Свободные слоты синхронизируются с Google Calendar Евгения.
          </p>
        </div>

        <div className="booking-shell">
          <div className="booking-panel">
            <span className="eyebrow" style={{ color: "#aaa49b" }}>Формат консультации</span>
            <div className="booking-options" role="listbox" aria-label="Выбор услуги">
              {options.map((option) => (
                <button
                  key={option.id}
                  className="booking-option"
                  aria-selected={selected === option.id}
                  onClick={() => choose(option.id)}
                >
                  {option.title}
                  <span>{option.meta}</span>
                </button>
              ))}
            </div>
            <p style={{ marginTop: 24, fontSize: 14 }}>
              Если подходящего времени нет, свяжитесь с Евгением напрямую — ближайшее возможное окно можно уточнить отдельно.
            </p>
          </div>

          <div className="booking-frame">
            {url ? (
              <iframe
                title="Запись на консультацию"
                src={url}
                loading="lazy"
                onLoad={openBooking}
                allow="clipboard-write; encrypted-media"
              />
            ) : (
              <div className="booking-empty">
                <div>
                  <span className="placeholder-tag">GOOGLE CALENDAR</span>
                  <h3>Расписание скоро будет доступно</h3>
                  <p className="muted" style={{ marginTop: 12 }}>
                    После восстановления Google Calendar сюда добавляются реальные ссылки на страницы записи. Сайт не хранит доступность слотов самостоятельно.
                  </p>
                  <p className="muted" style={{ marginTop: 12 }}>
                    {BOOKING_TIMEZONE_LABEL}
                  </p>
                  <a className="button button--primary" href="#contacts">Связаться напрямую</a>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}