"use client";

import { useEffect } from "react";
import { preserveUtmParams, trackEvent } from "@/lib/analytics";

export function AnalyticsBridge() {
  useEffect(() => {
    preserveUtmParams();
    trackEvent("page_view");

    const handler = (event: MouseEvent) => {
      const target = event.target as HTMLElement | null;
      const tracked = target?.closest<HTMLElement>("[data-track]");
      const name = tracked?.dataset.track;
      if (name) trackEvent(name);
    };

    const faqHandler = (event: MouseEvent) => {
      const target = event.target as HTMLElement | null;
      const details = target?.closest("details");
      if (details?.closest("#faq")) trackEvent("faq_open");
    };

    document.addEventListener("click", handler);
    document.addEventListener("click", faqHandler);
    return () => {
      document.removeEventListener("click", handler);
      document.removeEventListener("click", faqHandler);
    };
  }, []);

  useEffect(() => {
    const booking = document.getElementById("booking");
    if (!booking) return;

    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          trackEvent("booking_section_open");
          observer.disconnect();
        }
      },
      { threshold: 0.25 }
    );

    observer.observe(booking);
    return () => observer.disconnect();
  }, []);

  return null;
}