export const ANALYTICS_EVENTS = {
  pageView: "page_view",
  clickBook: "click_book",
  bookingSectionOpen: "booking_section_open",
  bookingServiceSelected: "booking_service_selected",
  bookingCalendarOpen: "booking_calendar_open",
  bookingCompleted: "booking_completed",
  telegramClick: "telegram_click",
  phoneClick: "phone_click",
  b17Click: "b17_click",
  vkClick: "vk_click",
  instagramClick: "instagram_click",
  mapClick: "map_click",
  serviceView: "service_view",
  faqOpen: "faq_open",
} as const;

declare global {
  interface Window {
    ym?: (
      counterId: number,
      method: string,
      target?: string,
      params?: Record<string, unknown>
    ) => void;
  }
}

export function trackEvent(
  event: string,
  params: Record<string, unknown> = {}
) {
  const id = process.env.NEXT_PUBLIC_YANDEX_METRICA_ID;
  if (!id || typeof window === "undefined" || !window.ym) return;

  const counterId = Number(id);
  window.ym(counterId, "reachGoal", event, params);
}

export function preserveUtmParams() {
  if (typeof window === "undefined") return;

  const url = new URL(window.location.href);
  const params = new URLSearchParams();

  [
    "utm_source",
    "utm_medium",
    "utm_campaign",
    "utm_content",
    "utm_term",
  ].forEach((key) => {
    const value = url.searchParams.get(key);
    if (value) params.set(key, value);
  });

  if (params.toString()) {
    sessionStorage.setItem("initial_utm", params.toString());
    localStorage.setItem("initial_utm", params.toString());
  }
}